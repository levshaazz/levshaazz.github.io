# Round 05 reference: a smaller scheduler token budget

Submit `round-05` by **5 November 2026,23:59 MSK (UTC+3)** in your registered
PRIVATE repository, with accepted `levshaazz` judge access. The 1 November late
exception covers Round01–04; it does not extend the Round05 deadline.

## One intervention from Topic05

The only runtime change from Round04 is:

```bash
--max-num-batched-tokens 1024
```

The observed control budget is2048. A scheduler iteration's token budget counts
scheduled tokens, not requests or the maximum context length. A smaller budget
changes how chunked prefill shares iterations with active decode requests; it can
change both throughput and latency. This is an end-to-end serving comparison,
not proof of a particular kernel or bandwidth mechanism.

Qwen/Qwen2.5-3B-Instruct revision `aa8e72537993ba99e69dfaafa59ed015b17504d1`, FP16 weights, automatic
unquantized KV dtype, vLLM0.29.0, TRITON_ATTN, max-num-seqs64,4096-token context,
GPU-memory fraction0.90, prefix caching and chunked prefill stay unchanged.
Students retain the existing model/stack choices and submission contract.

## All three public screens,2 November2026

| Budget | S, output tok/s | p95 TTFT@64, s | Initial gain | Decision |
|---:|---:|---:|---:|---|
| 2048 | 2635.45 | 0.5451 | — | Control |
| 1536 | 2660.20 | 0.4389 | +0.94% | Outside the predeclared1–5% selection band |
| 1024 | 2675.12 | 0.3510 | +1.51% | Frozen finalist |

The frozen rule preferred1536 only if it passed every non-quality gate and gained
1–5%; otherwise it considered1024. Thus1536 is retained as an ineligible result,
not rounded up to a passing1% gain. All three screens passed the technical gates.

## Three NEW matched pairs

| Pair / order | Control S, output tok/s | Candidate S, output tok/s | Gain |
|---|---:|---:|---:|
| 1: control / candidate | 2636.61 | 2676.75 | +1.52% |
| 2: candidate / control | 2634.62 | 2672.38 | +1.43% |
| 3: control / candidate | 2630.80 | 2670.65 | +1.51% |

Geometric mean gain: **+1.4900%**. Every pair gained speed and every call
passed all non-quality gates. The orders were fixed before measurement. Each
public call uses the fixed diagnostic seed20261024 and skips quality. These
finite comparisons are not statistical proof or a guarantee for another GPU.
The diagnostic workload and protected acceptance use the same configured pools;
a protected seed is not a claim of item-level disjointness.

## One separate protected full acceptance

After selection and confirmation, exactly ONE full acceptance measured:
S=2671.811403 output tok/s; p95 TTFT@64=0.2848s;
GSM8K=0.5850, IFEval=0.5650, MMLU-Pro=0.4643.
All required quality, request, length, canary, contract and cleanup gates passed.
The protected seed and raw judge logs are private. No second draw or quality-driven
retuning was used. Raw measurements are unscaled.

## Exact Round05 requirements

| Requirement | Round05 |
|---|---:|
| S_bar | 2671.8 output tok/s |
| p95 TTFT@64 | <=0.8s |
| GSM8K | >=0.4905 (49.05%) |
| IFEval | >=0.522 (52.20%) |
| MMLU-Pro | >=0.3793 (37.93%) |
| Request errors | <=1% |
| Each hidden length probe | >=95% of256 requested tokens |
| Mean paired canary similarity | >=0.8 |
| Unique-output share | >=0.75 |
| Short hidden outputs | 0 |

Only the speed bar changes. It is `floor(min(actual full S,2623.6*1.05)*10)/10`.
Quality floors are inherited EXACTLY from Round04; they are NOT recomputed as90%
of this result. Earlier rounds retain their own thresholds, seeds and awards.
Read the exact thresholds.json and reference.json included in this archive.

## Run and submit

Copy the reference runtime into your own registered private repository. Set
submission.yaml author to YOUR GitHub login and record YOUR experiments in
JOURNAL.md; commit uv.lock. On a suitable CUDA GPU:

```bash
bash prepare.sh
bash serve.sh
```

From another terminal, a literal PUBLIC streaming request is:

```bash
curl -N http://127.0.0.1:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"submission","messages":[{"role":"user","content":"Explain KV cache in one sentence."}],"max_tokens":32,"stream":true}'
```

This checks streaming, not the hidden benchmark. Run the public template's
contract CI and GPU smoke checks too; green CI is not a quality or speed grade.
Students arrange their own CUDA GPU. T4 speed is not the5070Ti threshold.
After reviewing and committing your solution:

```bash
git tag round-05
git push origin main round-05
```

Keep earlier tags. Individual questions: private repository Issue mentioning
@levshaazz; general nonsensitive questions: public submission example Issues.
Do not share tokens or request the protected judge seed.

The four executable/lock files equal the measured finalist. Manifest distinguishes
measured files from descriptive delivery changes. Old references and all rejected
screens remain retained. Current reference and results:
https://levshaazz.github.io/llm-serving-mastery/en/leaderboard/#round-05-reference
