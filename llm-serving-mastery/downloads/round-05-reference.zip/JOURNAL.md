# Round05 measured reference journal

Round05 Topic05 continuous batching: FP16/TRITON_ATTN with max-num-batched-tokens1024; same model/revision, vLLM0.29.0, seq64 and unquantized automatic KV dtype.

Three public screens:

| Budget | S, output tok/s | p95 TTFT@64, s | Initial gain | Decision |
|---:|---:|---:|---:|---|
| 2048 | 2635.45 | 0.5451 | — | Control |
| 1536 | 2660.20 | 0.4389 | +0.94% | Outside the predeclared1–5% selection band |
| 1024 | 2675.12 | 0.3510 | +1.51% | Frozen finalist |

Three new fixed-order matched pairs:

| Pair / order | Control S, output tok/s | Candidate S, output tok/s | Gain |
|---|---:|---:|---:|
| 1: control / candidate | 2636.61 | 2676.75 | +1.52% |
| 2: candidate / control | 2634.62 | 2672.38 | +1.43% |
| 3: control / candidate | 2630.80 | 2670.65 | +1.51% |

Geometric gain+1.489994percent. ONE protected full S=2671.811402775, TTFT64=0.2848s, quality={"gsm8k": 0.585, "ifeval": 0.565, "mmlu_pro": 0.4643}.
Student speedbar2671.8; original R4floors .4905/.522/.3793 and TTFT.8 unchanged. No protected retune/retry.
Raw results are unscaled. Source manifest binds measured runtime and descriptive delivery files.
This reference journal documents instructor measurements; students replace it with their own experiments.
