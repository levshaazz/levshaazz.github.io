# Round 06 measured reference journal

Topic 07: one-factor scheduler-budget search, FP16/TRITON_ATTN, same model/revision
and exact Round 05 runtime lock. Public development seed 20261024; public quality
calls 0. Ordered screens: 1024, 768, 512.

| Budget | S, output tok/s | p95 TTFT@64, s | Gain vs 1024 | Outcome |
|---:|---:|---:|---:|---|
| 1024 | 2671.173797 | 0.3509 | — | Retained control |
| 768 | 2663.131774 | 0.3281 | -0.3011% | Slower; outside the 1–5% eligibility band |
| 512 | 2641.839643 | 0.3258 | -1.0982% | Slower; outside the 1–5% eligibility band |

Neither smaller budget met the 1–5% eligibility rule. Confirmation calls 0.
The branch was frozen as unchanged control 1024 before protected initialization.
Exactly ONE new Round 06 full: S=2670.891604221, TTFT64=0.3511s,
quality={"gsm8k": 0.605, "ifeval": 0.585, "mmlu_pro": 0.3857}. All fixed non-speed gates passed.
The original strict speed check failed; its unchanged actualS was accepted by
the course owner with a 0.5% reference-machine-only allowance, host floor 2658.441.
The original strict-failure review and raw result remain retained. Student
S_bar 2671.8 and zero student tolerance are unchanged. No additional protected
full, seed change or quality-driven retune was used.

Student S_bar 2671.8, quality floors {"gsm8k": 0.4905, "ifeval": 0.522, "mmlu_pro": 0.3793},
TTFT <=0.8 s and all other checks remain exactly Round 05. No speed improvement is
claimed; retain the actual negative 768/512 evidence. Measurements are unscaled.

This journal documents instructor measurements. Students replace it with their
own hypotheses, concrete requests, configurations and observed results.
