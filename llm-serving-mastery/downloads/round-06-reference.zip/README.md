# Round 06 reference: measured unchanged baseline

Submit tag `round-06` by **12 November 2026, 23:59 MSK (UTC+3)** in your
registered PRIVATE repository. The `levshaazz` judge invitation must be accepted.
Students arrange their own CUDA GPU; local T4 throughput is not the RTX 5070 Ti bar.

## Topic 07: test a hypothesis and retain negative evidence

We tested one parameter: scheduler `--max-num-batched-tokens`, with 1024 as control,
then 768 and 512. The public development seed was 20261024; quality was skipped in
all three screens. The model, FP16 weights, unquantized automatic KV dtype,
vLLM 0.29.0, TRITON_ATTN, sequence cap 64, context 4096, GPU-memory fraction 0.90,
prefix caching and chunked prefill stayed fixed.

| Budget | S, output tok/s | p95 TTFT@64, s | Gain vs 1024 | Outcome |
|---:|---:|---:|---:|---|
| 1024 | 2671.173797 | 0.3509 | — | Retained control |
| 768 | 2663.131774 | 0.3281 | -0.3011% | Slower; outside the 1–5% eligibility band |
| 512 | 2641.839643 | 0.3258 | -1.0982% | Slower; outside the 1–5% eligibility band |

Both smaller budgets were slower in this finite comparison. Neither qualified
for the predeclared 1–5% gain band. There were **zero confirmation calls**.
The frozen branch retains **budget 1024** and **S_bar 2671.8 output tok/s**.
Round 06 claims no measured optimization gain. These observations apply to this
GPU and workload; they do not establish a universal causal mechanism.

## One new protected full acceptance

A separate Round 06 protected full on the pre-frozen control measured:
S=2670.891604221 output tok/s; p95 TTFT@64=0.3511s;
GSM8K=0.6050, IFEval=0.5850,
MMLU-Pro=0.3857. All fixed non-speed gates passed. The original
strict speed check failed: this S is 0.0340% below 2671.8.
The course owner accepted this same completed full using a **0.5% allowance for
the reference machine only** (host floor 2658.441). The original strict failure and
raw result remain retained; S is unscaled, with no extra protected full or seed.
The student target stays **2671.8**, with **zero student tolerance**. The exact
host-admission proof is included in `reference.json` and `thresholds.json`.

## Exact student requirements

| Requirement | Round 06 |
|---|---:|
| S_bar | 2671.8 output tok/s |
| p95 TTFT@64 | <=0.8 s |
| gsm8k | >=0.4905 (49.05%) |
| ifeval | >=0.522 (52.20%) |
| mmlu_pro | >=0.3793 (37.93%) |
| Request errors | <=1% |
| Each hidden length probe | >=95% of 256 requested tokens |
| Mean paired canary similarity | >=0.8 |
| Unique-output share | >=0.75 |
| Short hidden outputs | 0 |

Quality floors are inherited exactly from Round 05; they are not recomputed from
this new full. The unchanged branch retains 2671.8 even if its new full is faster.
Earlier rounds keep their own thresholds, seeds and awards. Read the included
`thresholds.json` and `reference.json` for exact aggregate data.

## Run, inspect streaming and submit

Copy the reference runtime into your registered private repository. Set
`submission.yaml` author to YOUR GitHub login, keep the model revision and stack
declarations accurate, and write YOUR experiments in `JOURNAL.md`. Commit uv.lock.

Install uv first and check that `uv --version` works. Run these commands from
this repository's root. The explicit project and environment paths keep uv in
the same project when the retained server script enters its cached-model alias.
Project/environment resolution was checked with uv 0.11.28 using a CPU-only stub;
this local setup check is separate from the measured GPU results above.

```bash
uv --version
export UV_PROJECT="$PWD"
export UV_PROJECT_ENVIRONMENT="$PWD/.venv"
bash prepare.sh
bash serve.sh
```

The two uv variables are documented in the [official uv environment reference](https://docs.astral.sh/uv/reference/environment/).

From a second terminal, send this literal public request:

```bash
curl -N http://127.0.0.1:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"submission","messages":[{"role":"user","content":"Explain KV cache in one sentence."}],"max_tokens":32,"stream":true}'
```

Run the public submission template's contract CI and GPU smoke checks. The curl
request checks streaming; green CI does not assign a quality or speed grade.
After inspecting and committing your actual solution:

```bash
git tag round-06
git push origin main round-06
```

Keep earlier tags. For individual questions or appeals, open an Issue in your
private repository and mention @levshaazz. General nonsensitive questions belong
in the public submission example's Issues. Keep credentials and protected judge
inputs private.

The four executable/lock files equal the measured control bytes. The manifest
separates those measured runtime files from descriptive delivery edits. Current
reference and results: https://levshaazz.github.io/llm-serving-mastery/en/leaderboard/#round-06-reference
