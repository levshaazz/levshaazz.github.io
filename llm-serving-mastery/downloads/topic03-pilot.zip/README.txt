Topic 03 engineering pilot: should we keep the 4-bit change?

This bundle contains a student notebook, the reviewed runtime infrastructure,
the optional editable exercise starter, and a source-hash manifest. It contains
no solved student functions, private files, full model checkpoint, or recorded GPU run.
The small NPZ contains a documented public-Qwen weight slice and activations.
Source: Qwen/Qwen2.5-0.5B-Instruct, revision 7ae557604adf67be50417f59c2c2f167def9a775.
Copyright 2024 Alibaba Cloud. Apache License 2.0 is included as QWEN-LICENSE.txt.
Original: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/tree/7ae557604adf67be50417f59c2c2f167def9a775
Modification: course export of layer-12 MLP down-projection rows 0-63 to FP16 NPZ,
with recorded FP32 user-position activations; not the original complete checkpoint.
The original code and synthetic tickets are course material; teaching influences
are credited in the notebook (MIT EfficientML and CMU Deep Learning Systems).

START HERE
1. Extract into a new directory. Open 03-quantization-pilot.ipynb locally, or upload
   the notebook to Colab. In Colab's Files pane, also upload topic03_pilot.py
   and topic03-real-layer.npz. Do not upload a whole repository or model cache.
   Keep these exact matching runner bytes: the notebook verifies its SHA256.
2. Work through CPU Part A. Two functions intentionally raise NotImplementedError
   until you derive scales and implement row-local grouped quantization.
   Compare toy group sizes None/4/2/1, then real groups None/4864/128/64/32.
   Build distributions, measure output errors, freeze a calibration-only choice
   under 4.30 bits/weight, then inspect held-out without retuning. Timing
   statistics are supplied with tests. Change the second output length to 96.
   The optional topic03_pilot_exercises.py exposes the same starter and tests as
   a normal file; it is not a hidden solution or an extra required assignment.
3. Read the measurement contract and inspect the three indicated runner functions.
   Predict the 24/96-token comparison before seeing the result.
4. Select a Linux CUDA GPU, check headroom, and explicitly set RUN_GPU=True.
   The notebook prepares a dedicated venv, reuses host Torch/CUDA and verified
   matching packages, and starts ONE bounded GPU worker. The normal Hugging Face
   cache is reused; do not delete weights between attempts or mount personal
   Drive unnecessarily. GPU availability is not guaranteed by the course.
5. Download the fresh evidence/.../result.json and your edited notebook before
   disconnecting Colab. Preserve a failed attempt separately; do not present it
   as complete evidence. Add one table/plot and a short keep/revert decision.

The initial CPU tests are supposed to fail on unfinished code. Do not replace
them with precomputed answers or disable them to reach the GPU cell.

RESOURCE AND EVIDENCE BOUNDARIES
Startup: idle GPU, >=5 GiB host RAM available, >=5 GiB device memory free;
>=3 GiB free cache disk if weights must be downloaded. During work, the runner
checks >=2 GiB host headroom and >=1 GiB device headroom. These sampled gates
are NOT an OS memory sandbox. Stop and diagnose an OOM, timeout or cleanup error;
do not lower a gate. The worker budget is 600 seconds, with 45 seconds of parent
teardown allowance. Existing historical v3 gates are a separate protocol.

Fixed-length sequence timings and twelve synthetic natural ticket answers are
different workloads. Five trials per format/length do not establish tail latency,
HTTP service performance or a robust universal speedup. Allocated/reserved bytes
are not total process VRAM. The format change affects representation AND execution
path. The separate profiler may be unavailable; never invent a kernel explanation.
Six public transfer cases are excluded from the default run, not a secret test.

CPU-ONLY ARTIFACT CHECK (after an actual completed GPU run)
    python topic03_pilot.py --validate path/to/result.json
This checks artifact completeness, not production quality or causal conclusions.

DELIVERABLES
Your edited notebook or readable student-code diff, topic03-layer-decision.json, original GPU result.json, one
table/plot, and a bounded decision memo. Submit student work privately. Review
notebook outputs before sharing; never export credentials or model caches.

INTEGRITY
SHA256SUMS.json records exact payload bytes and the runner hash. It is a drift
manifest, not a cryptographic signature or independent security certification.
No GitHub checkout, private repository access or unpublished branch is required.
The notebook and runner travel together in this download.
