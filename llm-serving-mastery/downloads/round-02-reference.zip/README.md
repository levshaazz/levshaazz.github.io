ROUND 02 REFERENCE: SAME BASELINE AS ROUND 01

Qwen/Qwen2.5-3B-Instruct revision aa8e72537993ba99e69dfaafa59ed015b17504d1
vLLM 0.29.0, FP16, max model length4096, GPU memory utilization0.90.
The five implementation files are unchanged from the verified Round01 baseline.
The reference measurements are from30September2026; this is NOT a new GPU run.

Original gates unchanged: GSM8K>=0.531, IFEval>=0.5355, MMLU-Pro>=0.4179;
geometric speed bar2505.2 output tok/s; TTFTp95 at64clients<=0.8s;
error rate<=0.01; mean canary similarity>=0.8; output diversity>=0.75;
each hidden length probe>=floor(requested*0.95), maximum0short outputs.

Use Linux x86_64 with an appropriate NVIDIA CUDA GPU and uv.
The judge preloads the exact model and provides a prepared offline runtime.
For your own machine set UV_PROJECT_ENVIRONMENT to a writable local directory
before prepare.sh; the default /runtime path is for the judge, not a promise of
write access on your computer. Model download needs network and sufficient disk.
Keep the immutable snapshot cached; do not download it again for each test.
This is a baseline implementation, not a promise of speed on another GPU.

Copy into your registered PRIVATE submission repository. Replace the placeholder
author in submission.yaml with your GitHub login. Keep your work journal.
Normal Round02 contract and measurements apply. Push round-02 by
15October2026 23:59MSK; invite levshaazz and confirm judge access.
The Round01 full-participation-credit/no-Overdrive exception is ROUND01 ONLY.
Never add credentials, hidden seeds, or private judge inputs to this package.
