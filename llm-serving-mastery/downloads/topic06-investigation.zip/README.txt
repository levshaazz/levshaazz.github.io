Topic 06 lab v3.6: graduated TODO scaffolding (A/B/C), title motif.
