Topic 06 lab v3.2: p50+p95 on the TTFT plot; language passes clean.
