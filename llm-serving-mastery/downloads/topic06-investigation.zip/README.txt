Topic 06 lab v3.3: inline plots render in Colab (Agg guard fix).
