Topic 06 lab v3.4: plot overlap fixes; line-level comments.
