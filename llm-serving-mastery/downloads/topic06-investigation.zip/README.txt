Topic 06 lab v3.1: incident-first, waterfall, annotated plots; error rate by outcomes (timeouts count).
