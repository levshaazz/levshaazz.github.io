Topic 06 lab v3.1: outcome-based error rate (timeouts count toward SLO errors).
