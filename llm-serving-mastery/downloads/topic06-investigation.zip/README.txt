Topic 06 lab: Where is the saturation knee? (v3 visual redesign)

Open seminars/06-high-concurrency.ipynb in Google Colab (free CPU is enough for
the default mock profile). Incident-first narrative, visible data, request
waterfall, annotated plots (SLO line + knee marker), wave summary and decision
tables, seven typed student functions. Raw journals are evidence.
Public mirror: levshaazz/llm-serving-mastery-submission-example classroom/.
