Topic 06 lab: Where is the saturation knee?

Open seminars/06-high-concurrency.ipynb in Google Colab (CPU is enough for the
default mock profile). Seven typed student functions; raw journals are evidence.
Public mirror: levshaazz/llm-serving-mastery-submission-example classroom/.
