"""LSM practice runtime gateway.

One thin FastAPI service in front of a real llama.cpp server:
- verifies the pinned model weights by sha256 before serving (download on first start),
- proxies OpenAI-style requests to the engine,
- measures every experiment (TTFT, wall, tokens) honestly on this machine,
- appends measurements to a hash-chained journal (append-only JSONL) that the
  lab page can read and re-verify with its own Python.

Localhost teaching instrument only. No auth because 127.0.0.1 only; do not
expose this port.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.datastructures import MutableHeaders

ENGINE_URL = os.environ.get("LSM_ENGINE_URL", "http://engine:8080")
SPEC_ENGINE_URL = os.environ.get("LSM_SPEC_ENGINE_URL", "http://engine-spec:8080")
MODEL_URL = os.environ.get(
    "LSM_MODEL_URL",
    "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/"
    "qwen2.5-0.5b-instruct-q4_k_m.gguf",
)
MODEL_PATH = Path(os.environ.get("LSM_MODEL_PATH", "/data/models/model.gguf"))
MODEL_SHA256 = os.environ.get(
    "LSM_MODEL_SHA256",
    "74a4da8c9fdbcd15bd1f6d01d621410d31c6fc00986f5eb687824e7b93d7a9db",
)
MODEL_BYTES = 491_400_032  # declared size; verified against the download
# Lab 16 draft model: SAME tokenizer family (Qwen2.5-0.5B-Instruct), coarser
# quant (Q2_K). Pinned like the main weights; failure is non-fatal — the base
# experiments must keep working without it.
DRAFT_MODEL_URL = os.environ.get(
    "LSM_DRAFT_MODEL_URL",
    "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/"
    "qwen2.5-0.5b-instruct-q2_k.gguf",
)
DRAFT_MODEL_PATH = Path(os.environ.get("LSM_DRAFT_MODEL_PATH", "/data/models/draft.gguf"))
DRAFT_MODEL_SHA256 = os.environ.get(
    "LSM_DRAFT_MODEL_SHA256",
    "9ee36184e616dfc76df4f5dd66f908dbde6979524ae36e6cefb67f532f798cb8",
)
DRAFT_MODEL_BYTES = 415_182_688
DRAFT_OK = False
JOURNAL_PATH = Path(os.environ.get("LSM_JOURNAL_PATH", "/data/journal.jsonl"))

GENESIS_PREV = "0" * 64


class PrivateNetworkAccessMiddleware:
    """Chrome's Private Network Access: a page on a more public network
    (github.io → this loopback service) sends a preflight carrying
    Access-Control-Request-Private-Network and blocks the fetch unless the
    response echoes Access-Control-Allow-Private-Network: true. This service
    is a localhost-only teaching instrument with CORS *, so consenting is safe.
    Raw ASGI middleware (not BaseHTTPMiddleware) to keep /v1/chat/completions
    streaming intact."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_with_pna(message):
            if message["type"] == "http.response.start":
                MutableHeaders(scope=message).setdefault(
                    "Access-Control-Allow-Private-Network", "true"
                )
            await send(message)

        await self.app(scope, receive, send_with_pna)


app = FastAPI(title="LSM practice runtime", version="1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
# registered AFTER CORSMiddleware so it ends up OUTSIDE it in the Starlette
# stack (add_middleware inserts at position 0 — the last-registered runs
# first): CORSMiddleware answers preflight OPTIONS itself, so only an
# outer middleware can stamp the PNA header onto its response
app.add_middleware(PrivateNetworkAccessMiddleware)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_model() -> None:
    """Download once, then verify the pinned sha256 — every start, no skips."""
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not MODEL_PATH.exists() or MODEL_PATH.stat().st_size != MODEL_BYTES:
        print(f"[gateway] downloading pinned weights: {MODEL_URL}", flush=True)
        with httpx.stream("GET", MODEL_URL, follow_redirects=True, timeout=None) as resp:
            resp.raise_for_status()
            tmp = MODEL_PATH.with_suffix(".part")
            done = 0
            with tmp.open("wb") as fh:
                for chunk in resp.iter_bytes(1 << 20):
                    fh.write(chunk)
                    done += len(chunk)
                    if done % (25 << 20) < (1 << 20):
                        print(f"[gateway]  {done / 1e6:.0f} / {MODEL_BYTES / 1e6:.0f} MB", flush=True)
        tmp.rename(MODEL_PATH)
    actual = sha256_file(MODEL_PATH)
    if actual != MODEL_SHA256:
        raise SystemExit(f"[gateway] FATAL: weights sha256 mismatch: {actual}")
    print(f"[gateway] weights verified: sha256 {actual[:16]}…", flush=True)


def ensure_draft_model() -> None:
    """Same contract as the main weights: download once, verify the pinned
    sha256 every start. Non-fatal: when the draft weights are unavailable the
    base (non-speculative) experiments must keep working, and /experiment with
    spec=true answers 503 honestly."""
    global DRAFT_OK
    DRAFT_OK = False
    try:
        DRAFT_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        if not DRAFT_MODEL_PATH.exists() or DRAFT_MODEL_PATH.stat().st_size != DRAFT_MODEL_BYTES:
            print(f"[gateway] downloading pinned draft weights: {DRAFT_MODEL_URL}", flush=True)
            with httpx.stream("GET", DRAFT_MODEL_URL, follow_redirects=True, timeout=None) as resp:
                resp.raise_for_status()
                tmp = DRAFT_MODEL_PATH.with_suffix(".part")
                done = 0
                with tmp.open("wb") as fh:
                    for chunk in resp.iter_bytes(1 << 20):
                        fh.write(chunk)
                        done += len(chunk)
                        if done % (25 << 20) < (1 << 20):
                            print(f"[gateway]  {done / 1e6:.0f} / {DRAFT_MODEL_BYTES / 1e6:.0f} MB", flush=True)
            tmp.rename(DRAFT_MODEL_PATH)
        actual = sha256_file(DRAFT_MODEL_PATH)
        if actual != DRAFT_MODEL_SHA256:
            raise RuntimeError(f"draft weights sha256 mismatch: {actual}")
        DRAFT_OK = True
        print(f"[gateway] draft weights verified: sha256 {actual[:16]}…", flush=True)
    except Exception as e:  # noqa: BLE001 — a missing draft must not kill the gateway
        print(f"[gateway] WARNING: draft model unavailable ({e}); spec experiments return 503", flush=True)


def wait_engine(deadline_s: float = 120.0) -> None:
    deadline = time.time() + deadline_s
    while time.time() < deadline:
        try:
            r = httpx.get(f"{ENGINE_URL}/health", timeout=2.0)
            if r.status_code == 200:
                print("[gateway] engine is ready", flush=True)
                return
        except httpx.HTTPError:
            pass
        time.sleep(1.0)
    print("[gateway] engine not ready yet; requests will fail until it is", flush=True)


@app.on_event("startup")
def startup() -> None:
    ensure_model()
    ensure_draft_model()
    wait_engine()
    if not JOURNAL_PATH.exists():
        genesis_entry()


# ------------------------------------------------------------------ journal
def entry_hash(seq: int, ts: str, kind: str, payload: dict, prev: str) -> str:
    canon = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    material = f"{seq}|{ts}|{kind}|{canon}|{prev}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def genesis_entry() -> dict:
    entry = {
        "seq": 0,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "kind": "genesis",
        "payload": {"note": "LSM practice runtime journal; append-only, hash-chained"},
        "prev": GENESIS_PREV,
    }
    entry["hash"] = entry_hash(entry["seq"], entry["ts"], entry["kind"], entry["payload"], entry["prev"])
    JOURNAL_PATH.parent.mkdir(parents=True, exist_ok=True)
    JOURNAL_PATH.write_text(json.dumps(entry, ensure_ascii=False) + "\n", encoding="utf-8")
    return entry


def read_journal() -> list[dict]:
    if not JOURNAL_PATH.exists():
        return [genesis_entry()]
    return [json.loads(line) for line in JOURNAL_PATH.read_text(encoding="utf-8").splitlines() if line.strip()]


def append_journal(kind: str, payload: dict) -> dict:
    entries = read_journal()
    prev = entries[-1]
    entry = {
        "seq": prev["seq"] + 1,
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "kind": kind,
        "payload": payload,
        "prev": prev["hash"],
    }
    entry["hash"] = entry_hash(entry["seq"], entry["ts"], entry["kind"], entry["payload"], entry["prev"])
    with JOURNAL_PATH.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry


# ------------------------------------------------------------------- routes
@app.get("/health")
def health() -> dict:
    engine_ok = False
    spec_ok = False
    try:
        engine_ok = httpx.get(f"{ENGINE_URL}/health", timeout=2.0).status_code == 200
    except httpx.HTTPError:
        pass
    try:
        spec_ok = httpx.get(f"{SPEC_ENGINE_URL}/health", timeout=2.0).status_code == 200
    except httpx.HTTPError:
        pass
    return {
        "status": "ok" if engine_ok else "engine-warming",
        "runtime": "lsm-practice/1.0",
        "engine": "llama.cpp server (pinned digest)",
        "model": {"file": MODEL_PATH.name, "sha256": MODEL_SHA256, "bytes": MODEL_BYTES},
        "spec_engine": {
            "ok": spec_ok and DRAFT_OK,
            "weights_ok": DRAFT_OK,
            "model": {"file": DRAFT_MODEL_PATH.name, "sha256": DRAFT_MODEL_SHA256, "bytes": DRAFT_MODEL_BYTES},
        },
        "journal_entries": len(read_journal()),
    }


@app.post("/v1/chat/completions")
async def chat(request: Request) -> StreamingResponse:
    """Plain OpenAI-compatible proxy to the engine (stream passthrough)."""
    body = await request.body()
    req = httpx.build_request("POST", f"{ENGINE_URL}/v1/chat/completions",
                              content=body,
                              headers={"Content-Type": "application/json"})
    upstream = await httpx.AsyncClient().send(req, stream=True)
    return StreamingResponse(upstream.aiter_raw(), status_code=upstream.status_code,
                             media_type=upstream.headers.get("content-type", "application/json"))


@app.post("/experiment")
async def experiment(request: Request) -> JSONResponse:
    """Run one measured request against the engine and journal it.

    Body: {"prompt": str, "max_tokens": int, "spec": bool}. spec=true routes
    to the speculative engine (draft model, draft-simple) — the Lab 16 A/B.
    The measurement happens on this machine; the client sees honest numbers,
    whatever they are (on a CPU the speculative engine usually LOSES — that
    measured contradiction is the lesson, not a bug).
    """
    spec = await request.json()
    prompt = str(spec.get("prompt", "Say hello in one short sentence."))
    max_tokens = max(1, min(int(spec.get("max_tokens", 32)), 128))
    use_spec = bool(spec.get("spec", False))
    if use_spec and not DRAFT_OK:
        return JSONResponse(
            {"error": "draft weights unavailable — the speculative engine is disabled; "
                      "run without the draft toggle"},
            status_code=503)
    target_url = SPEC_ENGINE_URL if use_spec else ENGINE_URL
    body = {
        "model": "local",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens,
        "stream": False,
    }
    t0 = time.perf_counter()
    try:
        r = httpx.post(f"{target_url}/v1/chat/completions", json=body, timeout=180.0)
    except httpx.HTTPError as e:
        return JSONResponse({"error": f"engine unreachable: {e}"}, status_code=503)
    ttft_s = None  # non-streaming upstream cannot observe TTFT honestly; we proxy streams for that
    wall_s = time.perf_counter() - t0
    if r.status_code != 200:
        return JSONResponse({"error": f"engine returned {r.status_code}", "detail": r.text[:400]},
                            status_code=502)
    data = r.json()
    usage = data.get("usage", {})
    tokens = int(usage.get("completion_tokens", 0))
    content = ""
    try:
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        pass
    tok_per_s = (tokens / (wall_s)) if wall_s > 0 else 0.0
    entry = append_journal("experiment", {
        "prompt_chars": len(prompt),
        "max_tokens": max_tokens,
        "spec": use_spec,
        "wall_s": round(wall_s, 4),
        "completion_tokens": tokens,
        "tok_per_s": round(tok_per_s, 2),
        "answer_head": content[:120],
    })
    return JSONResponse({
        "metrics": {
            "wall_s": round(wall_s, 4),
            "completion_tokens": tokens,
            "tok_per_s": round(tok_per_s, 2),
            "spec": use_spec,
        },
        "answer": content,
        "journal_seq": entry["seq"],
        "journal_hash": entry["hash"],
    })


@app.get("/journal")
def journal() -> dict:
    entries = read_journal()
    return {"entries": entries, "head": entries[-1]["hash"] if entries else None}


@app.get("/journal/verify")
def journal_verify() -> dict:
    entries = read_journal()
    prev = GENESIS_PREV
    for i, entry in enumerate(entries):
        if entry["seq"] != i:
            return {"ok": False, "broken_at": i, "reason": "seq gap"}
        expected = entry_hash(entry["seq"], entry["ts"], entry["kind"], entry["payload"], prev)
        if entry["hash"] != expected:
            return {"ok": False, "broken_at": i, "reason": "hash mismatch"}
        if entry["prev"] != prev:
            return {"ok": False, "broken_at": i, "reason": "prev pointer mismatch"}
        prev = entry["hash"]
    return {"ok": True, "entries": len(entries), "head": prev}


@app.post("/journal/note")
async def journal_note(request: Request) -> dict:
    """Append a student note (kind=note) — proves the chain grows from the client side."""
    spec = await request.json()
    note = str(spec.get("note", ""))[:280]
    entry = append_journal("note", {"note": note})
    return {"journal_seq": entry["seq"], "journal_hash": entry["hash"]}


# ------------------------------------------------------------------- burst
import concurrent.futures
import threading

_burst_slots = threading.Semaphore(1)  # one burst at a time on this tiny engine


@app.post("/burst")
async def burst(request: Request) -> JSONResponse:
    """A real admission drill: fire `arrivals` concurrent requests at the engine
    through a bounded admission envelope — `slots` in flight, `queue_slots`
    waiting, everything beyond that is rejected with an honest 429.

    Nothing here is simulated: the in-flight requests hit the real engine, the
    queued ones really wait for a slot, and the timing is whatever the student's
    machine produces.
    """
    spec = await request.json()
    arrivals = max(1, min(int(spec.get("arrivals", 24)), 64))
    slots = max(1, min(int(spec.get("slots", 4)), 8))
    queue_slots = max(0, min(int(spec.get("queue_slots", 4)), 16))
    max_tokens = max(1, min(int(spec.get("max_tokens", 16)), 64))
    prompt = str(spec.get("prompt", "Reply with a single short sentence."))

    if not _burst_slots.acquire(blocking=False):
        return JSONResponse({"error": "another burst is running; retry in a minute"}, status_code=409)
    try:
        admitted = min(arrivals, slots + queue_slots)
        rejected = arrivals - admitted
        sem = threading.Semaphore(slots)

        def one(i: int) -> dict:
            queued = i >= slots  # beyond the immediate slots, the request waits in queue
            wait_start = time.perf_counter()
            sem.acquire()
            waited_s = time.perf_counter() - wait_start
            t0 = time.perf_counter()
            try:
                r = httpx.post(f"{ENGINE_URL}/v1/chat/completions", json={
                    "model": "local",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": max_tokens, "stream": False,
                }, timeout=120.0)
                service_s = time.perf_counter() - t0
                ok = r.status_code == 200
                tokens = int(r.json().get("usage", {}).get("completion_tokens", 0)) if ok else 0
                return {"i": i, "status": 200 if ok else r.status_code, "queued": queued,
                        "queue_wait_s": round(waited_s, 3), "service_s": round(service_s, 3),
                        "completion_tokens": tokens}
            except httpx.HTTPError as e:
                return {"i": i, "status": 503, "queued": queued,
                        "queue_wait_s": round(waited_s, 3), "service_s": None, "error": str(e)[:80]}
            finally:
                sem.release()

        t0 = time.perf_counter()
        # every admitted request starts immediately; the bounded queue is the
        # slots semaphore — that wait is measured as queue_wait_s
        with concurrent.futures.ThreadPoolExecutor(max_workers=arrivals) as pool:
            per_request = list(pool.map(one, range(admitted)))
        wall_s = time.perf_counter() - t0

        completed = [r for r in per_request if r["status"] == 200]
        entry = append_journal("burst", {
            "arrivals": arrivals, "slots": slots, "queue_slots": queue_slots,
            "admitted": admitted, "rejected_429": rejected,
            "completed": len(completed), "wall_s": round(wall_s, 3),
            "median_service_s": sorted(r["service_s"] for r in completed)[len(completed) // 2] if completed else None,
            "max_queue_wait_s": max((r["queue_wait_s"] for r in per_request), default=0.0),
        })
        return JSONResponse({
            "config": {"arrivals": arrivals, "slots": slots, "queue_slots": queue_slots},
            "admitted": admitted,
            "rejected_429": rejected,
            "rejected_retry_after_s": 1 if rejected else None,
            "completed": len(completed),
            "wall_s": round(wall_s, 3),
            "per_request": per_request,
            "journal_seq": entry["seq"],
        })
    finally:
        _burst_slots.release()
