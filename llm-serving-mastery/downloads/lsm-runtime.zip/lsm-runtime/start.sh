#!/bin/sh
# LSM practice runtime: one-command start (macOS/Linux).
# Windows: run `docker compose up -d` in this folder instead.
set -e
cd "$(dirname "$0")"
docker compose up -d
echo "Waiting for the gateway (first start downloads 491 MB of weights)…"
for i in $(seq 1 120); do
  if curl -fsS http://127.0.0.1:8760/health >/dev/null 2>&1; then
    echo "Runtime is up: http://127.0.0.1:8760"
    curl -fsS http://127.0.0.1:8760/health
    echo
    exit 0
  fi
  sleep 3
done
echo "Gateway did not become healthy in 6 minutes; check: docker compose logs gateway"
exit 1
