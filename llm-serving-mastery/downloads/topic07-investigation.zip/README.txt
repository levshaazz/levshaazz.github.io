Topic 07 lab: four vLLM knobs, predeclared search, Pareto front, frozen profile.
