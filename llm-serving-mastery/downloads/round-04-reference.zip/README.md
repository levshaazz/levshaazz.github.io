# Round 04 reference: choose the attention worker, keep the model

Submit `round-04` by **29 October 2026, 23:59 MSK (UTC+3)** in your registered
PRIVATE repository. Invite `levshaazz` and confirm accepted read access before
the deadline. This example is not a submission on your behalf. Earlier tags stay frozen.

## One intervention from Topic 04

The vLLM API, scheduler and GPU worker are different responsibility zones.
Here we change the worker's attention implementation, not the model or API:

```bash
--attention-backend TRITON_ATTN
```

Same Qwen/Qwen2.5-3B-Instruct revision
`aa8e72537993ba99e69dfaafa59ed015b17504d1`, FP16 weights and KV cache,
vLLM 0.29.0, 4096-token context and `--max-num-seqs 64` as Round03. No quantization,
new checkpoint or model download. FLASH_ATTN is the control; TRITON_ATTN is the
one-factor candidate. These are attention backends, not different LLMs.

Topic 02 explains prefill/decode and why memory traffic and kernel execution
matter. Topic 04 explains where the backend sits in the serving stack. A different
implementation can have different overheads and floating-point operation order;
it is not necessarily faster and need not give bit-identical outputs. We measure
end-to-end service speed AND quality. This experiment alone does not prove a
specific bandwidth mechanism or global statistical quality equivalence.

## Actual measurements on the course judge

RTX 5070 Ti (16 GiB), driver 610.88, CPU 3800 MHz / Boost off, unchanged v5 benchmark and
corrected GuideLLM0.7.4 warmup-boundary driver on BOTH sides of each pair:

| Public diagnostic pair | Round03 control S, output tok/s | Candidate S, output tok/s | Gain |
|---|---:|---:|---:|
| First pair | 2566.68 | 2631.99 | 2.54% |
| Fresh confirmation pair | 2577.77 | 2630.50 | 2.05% |

These paired checks use the same public diagnostic draw, model, runtime and
measurement method. They do not compare a new driver with an old one. Then ONE
separate protected Round04 full acceptance produced S=2623.683840 output tok/s,
p95 TTFT@64=0.5471 seconds and quality GSM8K=0.545, IFEval=0.58,
MMLU-Pro=0.4643. All request, output-length, canary and cleanup checks passed.
This is finite operational acceptance, not proof of statistical quality equivalence
or a guarantee of the same performance on a different GPU.

## Two tempting changes that failed

On the same public diagnostic workload, increasing the batch-token budget alone
was not a usable improvement. These failures were retained before selecting the backend:

| Token budget | Raw S, output tok/s | p95 TTFT@64 | Result |
|---|---:|---:|---|
| 4096 | 2580.60 | 1.0931 s | Rejected: above0.8s |
| 8192 | 2566.74 | 1.9003 s | Rejected: above0.8s |

These are public reference-development experiments, not student scores. A slightly
larger raw throughput does not cancel a latency-gate failure. Do not blindly
copy the largest batch setting or attribute every latency spike to a judge bug.

## Exact Round04 grading requirements

| Requirement | Round04 |
|---|---:|
| S_bar | 2623.6 output tok/s |
| p95 TTFT@64 | <=0.8s |
| GSM8K | >=0.4905 (49.05%) |
| IFEval | >=0.522 (52.20%) |
| MMLU-Pro | >=0.3793 (37.93%) |
| Request error rate | <=1% |
| Each hidden length probe | >=95% of256 requested output tokens |
| Mean paired canary similarity | >=0.8 |
| Unique-output share | >=0.75 |
| Short hidden outputs | 0 |

The speed bar increases relative to corrected Round03. Quality can only remain
the same or become less strict; every other gate is unchanged. The bar is floored to0.1 output tok/s from the actual
full S, capped at105% of the previous2562.8 bar so this reference does not create
a greater-than5% difficulty step. Raw measurements are never scaled.
Each quality floor is min(corrected Round03 floor, rounded90% of THIS reference),
using4decimal places in fractions. This rule was fixed BEFORE the protected
Round04 acceptance. Read thresholds.json and reference.json; do not infer different floors
from a general calibration formula. No Round01–03 threshold or grade changes.

## Run and submit

Copy the reference runtime files into your own private solution repository.
Set submission.yaml author to YOUR GitHub login and add your real experiments to
JOURNAL.md. Keep the lock file committed. On a suitable CUDA GPU:

```bash
bash prepare.sh
bash serve.sh
```

From another terminal, a literal PUBLIC streaming smoke request is:

```bash
curl -N http://127.0.0.1:8000/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"submission","messages":[{"role":"user","content":"Explain KV cache in one sentence."}],"max_tokens":32,"stream":true}'
```

That request checks streaming only; it is NOT the hidden quality/speed benchmark.
Run the public starter's contract CI and GPU smoke checks as well. Green CI is
not a quality, latency or throughput grade. Students arrange their own CUDA GPU;
T4 availability is not guaranteed and its speed is not the5070Ti threshold.

After reviewing and committing YOUR solution:

```bash
git tag round-04
git push origin main round-04
```

Do not force-move earlier tags, share tokens or request the protected judge seed.
For individual questions, use an Issue in your private repository and mention
@levshaazz. General nonsensitive questions go to the public submission example.

Executable bytes in this ZIP equal the frozen measured candidate. Manifest
distinguishes original measured files from delivery-only metadata/JOURNAL/README
explanations. Old measurements, failed experiments and prior references are kept.

Course and current reference: https://levshaazz.github.io/llm-serving-mastery/en/leaderboard/#round-04-reference
Official pinned-version scheduling guidance: https://docs.vllm.ai/en/v0.29.0/configuration/optimization/#attention-backend-selection
