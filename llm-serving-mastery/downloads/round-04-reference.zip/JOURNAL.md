# Round04 reference journal

One intervention from Topic04: --attention-backend TRITON_ATTN, on the same Round03 seq64 FP16 model/runtime.

Round 04 uses Topic 04: the same FP16 Qwen2.5-3B/vLLM 0.29.0 reference and 64-sequence cap, with TRITON_ATTN instead of FLASH_ATTN. S_bar=2623.6 output tok/s, from actual full S=2623.683840, floored and capped at a 5% increase over Round 03. Each quality floor is min(corrected Round03 floor, rounded90% of THIS reference); no quality floor increases. TTFT stays 0.8 s, other gates stay unchanged. Round01–03 tags, thresholds and grades are unchanged. Push round-04 by 29 October 2026, 23:59 MSK, in your registered private repository with accepted levshaazz access.

Actual matched public pairs: [{"control_S": 2566.6791710301463, "candidate_S": 2631.994761886885, "gain_percent": 2.5447508825391596}, {"control_S": 2577.7687605757037, "candidate_S": 2630.502595208756, "gain_percent": 2.045716258167185}].
One protected full quality: {"gsm8k": 0.545, "ifeval": 0.58, "mmlu_pro": 0.4643}; TTFT64=0.5471s.

Rejected public token budgets: [{"max_num_batched_tokens": 4096, "S": 2580.603823526579, "TTFT64_s": 1.0931, "status": "rejected-public-screen", "reason": "TTFT above unchanged0.8s SLO"}, {"max_num_batched_tokens": 8192, "S": 2566.744371475274, "TTFT64_s": 1.9003, "status": "rejected-public-screen", "reason": "TTFT above unchanged0.8s SLO"}]. They remain rejected.

This journal, descriptive submission metadata and README are delivery explanations, not rewritten raw logs. Executable/lock bytes are exactly the measured candidate. See manifest.json.
