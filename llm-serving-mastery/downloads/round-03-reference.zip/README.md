# Round 03 FP16 reference: max-num-seqs 64

Only serving change from Round02: `--max-num-seqs 64`.
Original FLASH_ATTN attention remains; admission cap applies to every request.
Qwen2.5-3B-Instruct, exact revision in submission.yaml, vLLM0.29.0, FP16,
max model length4096 and GPU memory utilization0.90; no weight or KV quantization.
Runtime files are byte-identical to the measured source. Only descriptive YAML
notes and this example journal were updated for delivery; manifest records both.

23 October 2026 student-favorable quality correction: floors0.522/0.5355/0.3793
(GSM8K/IFEval/MMLU-Pro). Per benchmark, use the minimum of the originally
published floor and90percent of the already published Round03 reference score,
rounded to four decimal places in fractions. IFEval is NOT raised to0.5715.
The speed bar remains2562.8; TTFTp95@64<=0.8s and all error/length/diversity/canary
checks remain unchanged. Original15October artifacts are available under
downloads/history/round-03-20261015/ on the course site for audit, not current grading.
All admitted frozen Round03 submissions use the correction equally, including
quality failures. No retag/new solution is needed. Original commits, seed and raw
measurements stay fixed. No late-submission exception is introduced; no already
officially awarded base points/Overdrive may be reduced because of this correction.
See reference.json and thresholds.json for the actual measured values.
This is not a promise of performance on a different GPU or software stack.

Use Linux x86_64, an appropriate CUDA GPU and uv. Keep the exact model snapshot
cached. For local development set UV_PROJECT_ENVIRONMENT to a writable directory;
/runtime is the judge default, not a promise of local write access. Run prepare.sh
then serve.sh; the API is OpenAI-compatible at port8000, model name submission.

Copy into your registered PRIVATE repository, replace the author placeholder,
keep your own journal, and confirm levshaazz can access the repository. Round03
tag is round-03; deadline22October2026 23:59MSK. Round02 rules/deadline are unchanged.
Never add tokens, hidden judge inputs or credentials. The protected seed stays
with the judge. Published speed bar: **2562.8 output tokens/s** (+2.30% versus
Round 02). The measured S is 2562.893654, not a guarantee on other hardware.

Public paired checks showed +3.11% and +2.62%. The fixed-seed acceptance passed
all gates; this is operational validation, not a new unseen holdout or a proof
of identical outputs/statistical quality equivalence. All Round 02 bars remain
unchanged. Normal tags, grading and Overdrive rules apply to Round 03; the
Round 01 participation-credit exception does not extend to later rounds.
