# Round03 reference journal

Only intervention: `--max-num-seqs 64`. Original FLASH_ATTN and FP16 weights, runtime and workload remain.

Measured reference S=2562.893654 output tok/s; published candidate bar=2562.8.
Quality: {"gsm8k": 0.58, "ifeval": 0.635, "mmlu_pro": 0.4214}.
TTFTp95@64=0.5832s.

All experiments, including rejected candidates, remain in the private instructor audit. This is a measured example; keep your own experiment journal.
